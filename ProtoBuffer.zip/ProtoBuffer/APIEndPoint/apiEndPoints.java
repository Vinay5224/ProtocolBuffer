package com.secured.api.endpoints;

import static spark.Spark.*;
import org.json.*;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.slf4j.LoggerFactory;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.varia.NullAppender;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.catalyst.encoders.ExpressionEncoder;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructType;

import com.secured.SecuredUtils;
import com.secured.api.SecureDConstants;
import com.secured.api.apiCalls;
import com.sotero.proto.AddSbtest;
import com.sotero.proto.SbTestProtos.SbTestMsgs;

import redis.clients.jedis.Jedis;
import spark.Route;

public class apiEndPoints {
	final private static org.slf4j.Logger log = LoggerFactory.getLogger(apiEndPoints.class);
	static apiCalls c;
	static JSONObject obj;
	static SecuredUtils u;
	static apiEndPoints api = new apiEndPoints();
	public static Map<String, String> sCache = new HashMap<String, String>();

	public apiEndPoints() {
		apiEndPoints.c = new apiCalls();
		// apiEndPoints.u = new SecuredUtils();
	}

	public apiEndPoints(int reload) {
		apiEndPoints.c = new apiCalls(reload);
		// apiEndPoints.u = new SecuredUtils();
	}

	public static String getDecryptedVal(String value, String columnname, String tablename, String appId)
			throws Exception {

		String dv = "";
		try {
			dv = apiCalls.decryptDataValue(columnname, value, tablename, appId);

		} catch (NullPointerException e) {
			e.printStackTrace();
			dv = "";
		}
		System.out.println("In DECRYPT" + dv);
		return dv;
	}

	public static String getHeaders(int[] arg1, String arg2, String appId) throws Exception {
		String encCol = "";
		String encarg1 = "";
		int columnStart = 0;
		for (int i = 1; i < arg1.length; i += 3) {
			String enctabName = arg2.substring(columnStart, columnStart + arg1[i - 1]);
			String tabName = apiCalls.getEncryptedTableName(enctabName, appId);
			columnStart = columnStart + arg1[i - 1];
			String enccolName = arg2.substring(columnStart, columnStart + arg1[i]);
			String col1 = apiCalls.getEncryptedColName(enccolName, appId);
			// String encType = apiCalls.getEncType(tabName,col1);
			columnStart = columnStart + arg1[i];
			String encColValue = arg2.substring(columnStart, columnStart + arg1[i + 1]);
			String col2 = apiCalls.getEncryptedColName(encColValue, appId);
			columnStart = columnStart + arg1[i + 1];
			encCol += tabName + col1 + col2;
			encarg1 += "" + tabName.length() + "," + col1.length() + "," + col2.length() + ",";
			// System.out.println(enctabName + "|" + "|" + enccolName + "|" +
			// "|" + encColValue);
		}
		encarg1 = encarg1.replaceAll(",$", "");
		return encarg1 + " " + encCol;
	}

	public static String TCV(int[] arg1, String arg2, String appId) throws Exception {

		// System.out.println("Table Name:" + arg2.substring(0, arg1[0]));
		u = new SecuredUtils();
		int columnStart = 0;
		String encCol = "";
		String encarg1 = "";
		String columnName = "";
		String value = "";
		String encValue = "";
		String tableName = "";
		String enctabName = "";

		for (int i = 1; i < arg1.length; i += 3) {
			columnName = arg2.substring(columnStart + arg1[i - 1], columnStart + arg1[i] + arg1[i - 1]);
			value = arg2
					.substring(columnStart + arg1[i] + arg1[i - 1], columnStart + arg1[i - 1] + arg1[i] + arg1[i + 1])
					.toString();
			enctabName = arg2.substring(columnStart, columnStart + arg1[i - 1]);
			tableName = apiCalls.getEncryptedTableName(enctabName, appId);
			String clearColName = apiCalls.getEncryptedColName(columnName, appId);

			if (value.length() != 0) {
				value = apiCalls.decryptDataValue(columnName, value, tableName, appId);
			}
			columnStart = columnStart + arg1[i + 1] + arg1[i - 1] + arg1[i];

			encarg1 += "" + tableName.length() + "," + clearColName.length() + "," + value.length() + ",";
			encCol += tableName + clearColName + value;
		}
		encarg1 = encarg1.replaceAll(",$", "");
		return encarg1 + " " + encCol;
	}

	private static String BTCV(int[] withColumnArg1, String arg2, String appId) {

		String result = "";

		int[] arg1 = Arrays.copyOfRange(withColumnArg1, 1, withColumnArg1.length);
		try {
			// System.out.println(Arrays.toString(arg1));
			// System.out.println(arg2);
			result = TCV(arg1, arg2, appId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return withColumnArg1[0] + "," + result;

		// ArrayList<Integer> arrarg1 = new ArrayList<>(
		// Arrays.stream(withColumnArg1).boxed().collect(Collectors.toList()));
		//
		// // System.out.println(arrarg1);
		//
		// ArrayList<Integer> cpyarg1 = new ArrayList<>(arrarg1);
		// ArrayList<Integer> columnnumber = new ArrayList<>();
		//
		// int presentcolumn = cpyarg1.get(0);
		// int j = 0;
		// int k = 1;
		// System.out.println(cpyarg1);
		// for (int i = 0; i < cpyarg1.size(); i++) {
		// //System.out.println(presentcolumn);
		// // System.out.println(i);
		// // System.out.println(j);
		// if (i == 0) {
		// arrarg1.remove(i);
		// columnnumber.add(presentcolumn);
		// j = presentcolumn * 3;
		// } else if (i == j) {
		// // System.out.println("hello");
		// presentcolumn = cpyarg1.get(i + k);
		// k += k;
		// columnnumber.add(presentcolumn);
		// arrarg1.remove(i);
		// System.out.println(presentcolumn);
		// j = j + presentcolumn * 3;
		// System.out.println(j);
		// }
		// }
		//
		// Integer[] columnarg = columnnumber.toArray(new
		// Integer[columnnumber.size()]);
		// Integer[] arg1 = arrarg1.toArray(new Integer[arrarg1.size()]);
		//
		// System.out.println(columnnumber);
		// System.out.println(arrarg1);
		//
		//
		// int index = 0;
		// int columnStart = 0;
		// String encCol = "";
		// String encarg1 = "";
		// String columnName = "";
		// String value = "";
		// String encValue = "";
		// String tableName = "";
		// int columnlen = 0;
		//
		// System.out.println("path4");
		// System.out.println(Arrays.toString(arg1));
		// System.out.println(arg2);
		// for (int i = 1; i < arg1.length; i += 3) {
		// columnName = arg2.substring(columnStart + arg1[i - 1], columnStart +
		// arg1[i]
		// + arg1[i - 1]);
		// value = arg2
		// .substring(columnStart + arg1[i] + arg1[i - 1], columnStart + arg1[i
		// - 1] +
		// arg1[i] + arg1[i + 1])
		// .toString();
		// tableName =
		// apiCalls.getEncryptedTableName(arg2.substring(columnStart,
		// columnStart + arg1[i - 1]));
		// String clearColName = apiCalls.getEncryptedColName(columnName);
		// if (value.length() != 0) {
		// // System.out.println(value);
		//
		// value = apiCalls.decryptDataValue(columnName, value, tableName);
		// }
		// columnStart = columnStart + arg1[i + 1] + arg1[i - 1] + arg1[i];
		// // if(i==1||i>=columnlen) {
		// // encarg1 +=
		// //
		// ""+columnarg[index]+","+tableName.length()+","+clearColName.length()+","+value.length()+",";
		// // columnlen+= columnarg[index]*3;
		// // index++;
		// // //System.out.println(columnlen);
		// //
		// //
		// // }
		// // else {
		// encarg1 += "" + tableName.length() + "," + clearColName.length() +
		// "," +
		// value.length() + ",";
		// // System.out.println(encarg1);
		// // }
		// encCol += tableName + clearColName + value;
		// // System.out.println(i);
		// }
		//
		// System.out.println(encarg1);
		// System.out.println(encCol);
		// encarg1 = encarg1.replaceAll(",$", "");
		// return encarg1 + " " + encCol;

	}

	public static void main(String a[]) throws SQLException {

		// redis port
		int port = 6379;
		// int port = 6380;
		// Jedis jedis = new Jedis("localhost", port);
		// jedis.flushAll();
		String appId = "78";
		// SecureDConstants.APP_ID=appId;

		// api port
		port(45670);
		// port(4580);
		int maxThreads = 2000;
		int minThreads = 200;
		int timeOutMillis = 30000;
		threadPool(maxThreads, minThreads, timeOutMillis);
		System.setProperty("org.eclipse.jetty.util.log.class", "org.eclipse.jetty.util.log.StdErrLog");
		System.setProperty("org.eclipse.jetty.LEVEL", "OFF");

		Logger.getLogger("com.securedmeta.jdbc.redis.RedisClient").setLevel(Level.OFF);
		Logger.getLogger("org").setLevel(Level.OFF);
		Logger.getRootLogger().setLevel(Level.OFF);

		Logger.getRootLogger().removeAllAppenders();
		Logger.getRootLogger().addAppender(new NullAppender());

		api = new apiEndPoints();

		// SparkConf conf = new SparkConf().setAppName("SOME APP
		// NAME").setMaster("local[4]").set("spark.executor.memory",
		// "2g");

		// SparkSession spark =
		// SparkSession.builder().config(conf).getOrCreate();
		// SQLContext sqlCtx = new SQLContext(spark);

		// spark.udf().register("getTableName", new UDF1<String, String>() {
		// @Override
		// public String call(String tabName) {
		// return apiCalls.getEncryptedTableName(tabName);
		// }
		// }, DataTypes.StringType);

		// spark.udf().register("getColName", new UDF1<String, String>() {
		// @Override
		// public String call(String colName) {
		// return apiCalls.getEncryptedColName(colName);
		// }
		// }, DataTypes.StringType);

		try {

			Class.forName("com.mysql.jdbc.Driver");
			// Class.forName("com.secured.engine.spy.SecureDriver");

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your msql JDBC Driver?");
			e.printStackTrace();
			return;
		}

		// System.out.println();

		get("/", (req, res) -> {
			System.setProperty("enable.column.encrypt", "true");
			return "Jetty Server Started";
		});

		get("/path1", (req, res) -> {
			String v_sql = req.queryParams("arg1");
			String v_appid = req.queryParams("aid");
			String v_transid = req.queryParams("tid");

			// Stubbing
			/*
			 * if (1 == 1) { return v_sql; }
			 */
			if (v_appid == null) {
				v_appid = appId;
			}
			System.setProperty("enable.column.encrypt", "true");
			/*
			 * if (jedis.exists(v_sql+v_appid) == false) {
			 * 
			 * System.out.println(v_sql); String mod_sql =
			 * apiCalls.translateStatement(v_sql,v_appid);
			 * jedis.set(v_sql+v_appid, mod_sql); jedis.expire(v_sql, 60 * 60);
			 * return mod_sql; } else { String mod_sql =
			 * jedis.get(v_sql+v_appid); return mod_sql; }
			 */

			if (sCache.containsKey(v_sql + v_appid)) {
				String mod_sql = sCache.get(v_sql + v_appid);
				// String mod_sql = apiCalls.translateStatement(v_sql,v_appid);
				// System.out.println(mod_sql);
				return mod_sql;
			} else {
				String mod_sql = apiCalls.translateStatement(v_sql, v_appid);
				sCache.put(v_sql + v_appid, mod_sql);
				// System.out.println(mod_sql);
				return mod_sql;
			}

		});

		get("/path2", (req, res) -> {
			System.setProperty("enable.column.encrypt", "true");
			// System.out.println(req);
			String[] arg1 = req.queryParams("arg1").split(",");
			String arg2 = req.queryParams("arg2");

			/*
			 * if (1 == 1) { return arg1 + " " + arg2; }
			 */

			String v_appid = req.queryParams("aid");
			String v_transid = req.queryParams("tid");
			if (v_appid == null) {
				v_appid = appId;
			}

			// String v_appid = req.queryParams("appId");
			int length1 = 0;
			int[] intArray = new int[arg1.length];
			for (int i = 0; i < arg1.length; i++) {
				String numberAsString = arg1[i];
				length1 = length1 + Integer.parseInt(numberAsString);
				intArray[i] = Integer.parseInt(numberAsString);
			}
			if (length1 != arg2.length())
				return "ARG1_LENGTH=" + length1 + " AND " + "ARG2_LENGTH=" + arg2.length() + " ARE NOT EQUAL arg2="
						+ arg2;
			else
				return getHeaders(intArray, req.queryParams("arg2"), v_appid);

		});

		get("/path3", (req, res) -> {
			String arg2 = req.queryParams("arg2");
			String v_appid = req.queryParams("aid");
			String v_transid = req.queryParams("tid");
			if (v_appid == null) {
				v_appid = appId;
			}

			// String v_appid = req.queryParams("appId");
			System.setProperty("enable.column.encrypt", "true");
			String[] arg1 = req.queryParams("arg1").split(",");
			int length2 = 0;
			int[] intArray = new int[arg1.length];
			for (int i = 0; i < arg1.length; i++) {
				String numberAsString = arg1[i];
				length2 = length2 + Integer.parseInt(numberAsString);
				intArray[i] = Integer.parseInt(numberAsString);
			}
			if (length2 != arg2.length())
				return "ARG1_LENGTH=" + length2 + " AND " + "ARG2_LENGTH=" + req.queryParams("arg2").length()
						+ " ARE NOT EQUAL arg2=" + arg2;
			else
				return TCV(intArray, req.queryParams("arg2"), v_appid);
		});

		post("/path4", (req, res) -> {
			// System.out.println(req.body());

			JSONObject obj = new JSONObject(req.body());
			String arg = obj.getString("arg1");
			String arg2 = URLDecoder.decode(obj.getString("arg2"), "UTF-8");
			String v_appid = obj.getString("aid");
			String v_transid = obj.getString("tid");
			if (v_appid == null) {
				v_appid = appId;
			}

			System.setProperty("enable.column.encrypt", "true");
			String[] arg1 = arg.split(",");
			int length2 = 0;
			int[] intArray = new int[arg1.length];
			for (int i = 0; i < arg1.length; i++) {
				String numberAsString = arg1[i];
				length2 = length2 + Integer.parseInt(numberAsString);
				intArray[i] = Integer.parseInt(numberAsString);
			}

			return BTCV(intArray, arg2, v_appid);
		});

		post("/path6", (req, res) -> {

			log.debug("started calling /path6");
			final long startTime = System.nanoTime();
			try {
				// System.out.println(req.body());
				obj = new JSONObject(req.body());
				/*
				 * if ( 1 == 1) { return req.body(); }
				 */

			} catch (Exception e) {

				e.printStackTrace();
			}

			List<String> tableNamesList = new ArrayList<String>();
			List<String> colNamesList = new ArrayList<String>();
			List<String> encTypeList = new ArrayList<String>();
			// System.out.println("In the loop");
			String v_appid = obj.getString("aid");
			String v_tid = obj.getString("tid");
			if (v_appid == null) {
				v_appid = appId;
			}
			JSONArray records = obj.getJSONArray("RECORDS");
			log.debug("Path6 is Processing No.Of records " + records.length());
			for (int i = 0; i < obj.getJSONArray("COLUMNS").length(); i++) {
				JSONObject col = obj.getJSONArray("COLUMNS").getJSONObject(i);
				String tablename = apiCalls.getEncryptedTableName(col.getString("tablename"), v_appid);
				String columnname = apiCalls.getEncryptedColName(col.getString("name"), v_appid);
				col.put("tablename", tablename);
				col.put("name", columnname);
				tableNamesList.add(tablename);
				colNamesList.add(columnname);
				encTypeList.add(apiCalls.getEncType(tablename, columnname, v_appid));
			}

			JSONProcessor t = null;

			JSONArray results = t.decrypt(records, tableNamesList, colNamesList, encTypeList, u, v_appid);

			String ret_str = "{\"COLUMNS\" :" + obj.getJSONArray("COLUMNS") + ",\"RECORDS\":" + results.toString()
					+ "}";
			// System.out.println(ret_str);
			log.debug("Path6 enpoint completed  =====" + ((System.nanoTime() - startTime) / 1000000) + " ms");
			return ret_str;

		});

		post("/path5", (req, res) -> {
			log.debug("started calling /path5");
			final long startTime = System.nanoTime();
			String v_appid = null;
			/*
			 * if ( v_appid == null ) { String ret_str =
			 * "{\"RECORDS\":[{\"0\":\"36539093500-82500478004-88677756589-57153324732-87474712824-25382712474-80192609086-66806981827-82805055308-97090777206\"},{\"0\":\"63702355376-55686940637-31592728212-99604585179-57196594744-10988166294-07831203016-01816900289-84634796151-51862506963\"},{\"0\":\"63512179625-48256726778-62130630349-55121265969-70020689949-66167448436-25855394493-93662013038-45970290230-43945274127\"},{\"0\":\"47950053508-13467850010-62939250107-97383354499-00023129719-68682065443-81400981598-10110309415-90655880899-15341162887\"},{\"0\":\"44970200538-67003126272-45143262924-60346302618-10697207967-19122656462-76118347821-46881162338-39840876689-65532925879\"},{\"0\":\"33172347449-77481453930-58418661518-27787842206-35181476942-21825599228-07314273299-68369834072-60710017508-19199602720\"},{\"0\":\"36632721811-46412839819-93589281426-39324047733-21852720316-72970171784-67055689183-27127131689-46087042551-97541601983\"},{\"0\":\"73484774390-84501192215-45922807882-35825300803-94138508661-18832532070-29409159493-17891645382-82422417841-33932953815\"},{\"0\":\"27940490221-40138554367-12834201323-17490758124-71354186647-53020238470-63718837055-94163780506-97218071338-68842894112\"},{\"0\":\"23104174972-14792227543-23168325542-49235280214-98879948197-52624445359-45749366860-19604999259-31578152777-16835123906\"},{\"0\":\"37204945658-42948582917-45934080186-56677575873-23823380262-08257831020-55472291420-19481966155-03837067925-84441707404\"},{\"0\":\"04159459783-39730066974-18492241653-37306173835-97184220380-44411766243-61146756935-72426316494-03612738807-41581108726\"},{\"0\":\"50927390191-95081894739-91615053518-93499903319-38448354710-55057651525-44183334547-21218189729-59540472099-63643880708\"},{\"0\":\"09511400912-04087940699-25999801568-45590284379-07432291309-93732889686-27237540575-22611349660-44060004004-88872156807\"},{\"0\":\"40963155390-94587229802-58531214322-91434282414-52369514771-43414057908-69259601885-06436133628-30483552438-24344482642\"},{\"0\":\"51001781407-60582113521-76402537975-36763659502-18888529057-41626246228-43332350433-70546455737-05151195720-94386876501\"},{\"0\":\"28776532585-13832837078-98579699787-52432767996-37378742112-77192243649-04237124939-84580919719-78773762438-71799537863\"},{\"0\":\"59490636734-77951414416-00852516388-33234023406-12877593270-06741119653-47222935462-12689057082-10288425169-32577549945\"},{\"0\":\"92169869134-25686243531-72805946951-87841115424-17158860543-86161642994-70044272553-30253193168-13708603754-21651014250\"},{\"0\":\"96387965170-61038092758-22018820482-32554145180-88820494902-71001596473-35434423434-78954996286-14213097167-09103907405\"},{\"0\":\"00245070501-98015850230-57208313111-34152133611-58237811388-76784607078-59742264163-86729337509-41092380715-66729685782\"},{\"0\":\"59907303095-32772571798-66004410391-89735564481-96926914470-45790745933-01839839710-23313181773-10418796937-27586746223\"},{\"0\":\"31859014532-00162250979-78740272844-52406016109-74921090522-22154584143-30132334892-47169711425-66928864986-45817087831\"},{\"0\":\"70959807133-18545148592-23289128559-77628870517-21175322578-00376575534-09478813476-16734403541-51630226585-46126869407\"},{\"0\":\"69416777743-81781895906-81495675795-82240977987-70820110116-98641133021-53707254839-91203202124-32232641033-08531568817\"},{\"0\":\"64461047197-04694846141-70876261450-89901943869-08579861170-67622511393-24749813587-76777159694-55342600897-76303366411\"},{\"0\":\"10484429575-59057392176-29040936420-62892281531-16163831198-51312971661-44111256751-61581108024-92832679841-24059603994\"},{\"0\":\"40880856395-59730973317-99895331830-03588860498-56612683368-27593276530-87237115526-09231441985-11587125449-73422634379\"},{\"0\":\"34230528668-46327919004-00993019538-78823176505-00743730609-01862114398-38271422436-81828666381-31390980328-58103889593\"},{\"0\":\"38727708094-57624772616-07462797227-76992390842-87005175432-58345807665-27779082809-53968783132-49746927732-27271065043\"},{\"0\":\"39645452466-61968760708-40136142011-52715164322-16248441476-27353511198-28450964193-32561248100-60505494649-07801303345\"},{\"0\":\"82934506253-38309361310-88552417653-89137899483-27179805826-72580338048-25957624409-00733972408-45090671920-05785305095\"},{\"0\":\"65562743830-94065938798-42017178344-89560144618-92388911586-68408951761-39205882059-05931619375-78820403228-68324262903\"},{\"0\":\"85495403661-32965184859-69334966880-02607190136-27940317930-70552466906-57923507549-71612796940-41511128314-60148267615\"},{\"0\":\"21595300620-14192259216-80215996922-60231531751-08408650597-73233914426-47040362213-88786219704-93919433227-57982466227\"},{\"0\":\"43989559708-02928341580-55578951039-53658822605-20093773370-92975834727-87533853640-26465924742-56827474341-57355828113\"},{\"0\":\"71088044834-78042166681-31374830321-26179029807-45087378599-13283055339-46443709500-89857944673-36414256334-67868997332\"},{\"0\":\"11216065385-40417249578-06765185000-69102754012-05904909187-48282710656-63340341807-90202978615-75422221593-78569654953\"},{\"0\":\"22163526378-03862727361-47337983778-86178044811-79586023634-79556046428-78480082907-33008210380-90239872817-28861273294\"},{\"0\":\"91450640285-41413250271-59985873436-86081900729-32718065606-44948457329-12455828275-24398113055-81510684001-08041009504\"},{\"0\":\"50223062437-00758412732-28851736980-58160441951-99107655603-54130755595-62731628139-56077496102-08426557548-80116060467\"},{\"0\":\"37896363231-43132792449-63591919757-83885332242-64666606499-80892279736-11743603351-67572033060-59506167703-80164576647\"},{\"0\":\"60913196228-00663357379-85657399397-96471678859-87086863726-79633939709-44910474372-69656143419-88423943922-36708236481\"},{\"0\":\"46695121734-58621133091-26660667146-61424987790-63743029626-61809426599-47277154690-98947636064-18146999740-61090371745\"},{\"0\":\"14838302448-70090041976-21740696275-26747857523-73308465052-42264871588-01397358107-80191107123-39418164532-96873984209\"},{\"0\":\"78867197913-21231325944-02860497303-41529797736-10546600552-66921432172-26435487926-19013936314-10941157993-00417030360\"},{\"0\":\"47701069002-00480250692-48357493710-73569126069-75242736286-45440510853-24593929818-87441883477-45441666090-90699964757\"},{\"0\":\"86658747834-20577636294-71361130912-77516547422-61409522433-97356212551-84780250330-23004318305-82286154777-29472571334\"},{\"0\":\"66841836005-69241844201-77079642422-00440707370-94740217219-31902010389-37007938455-78849304430-60961318280-30368810990\"},{\"0\":\"63407398336-10973799840-35353184498-13244662575-00404762182-07935635886-74099973038-20686757609-81301295521-49837543004\"},{\"0\":\"99758007089-09308916649-83411577585-51904115016-03099919446-71539785407-10700509905-85108991558-93060206119-04596398465\"},{\"0\":\"40966026491-24447535092-68169471165-21295485540-11197438245-89109979529-64100599051-20648219630-46327401827-36714317649\"},{\"0\":\"78285244314-18405339096-89660687191-53304520415-64767669766-45589703001-02062181373-07988379230-17983514719-07291444327\"},{\"0\":\"74382011442-06400364709-71827455997-04229927129-08225985816-31329328094-86659880730-66130369219-75151225709-11387192121\"},{\"0\":\"82124374002-32852002152-94327912928-20959616347-52587230219-09136830535-12542204479-18963152951-70893801232-28839546253\"},{\"0\":\"47419726470-54715084335-90258887830-00750579910-69839546087-96314472785-76579151927-42517017677-16601405071-29795952297\"},{\"0\":\"00178590377-87457309031-90768920102-84743630439-48318049565-58830931262-38893790086-91772702034-37592898343-93960243943\"},{\"0\":\"70638918015-65483596163-61981116505-81588884257-20586080243-48683164645-75388471647-43785213230-73517637680-68473878283\"},{\"0\":\"61218396448-59018516048-84599624631-95398493389-93712032986-19390449365-14826133669-71551004549-94319150724-22000704770\"},{\"0\":\"17154003496-94323998555-03210136165-74131063646-23774572049-35636460107-75916918241-92345427216-36296126088-37884781645\"},{\"0\":\"70615611062-40004966213-33860243358-87235844669-81057514074-55846355317-71044481801-56570272682-02729501914-17344261436\"},{\"0\":\"05166511239-61738667039-85680327795-58433895627-40383633971-88076930341-34274249118-05784524808-03768672193-04794722393\"},{\"0\":\"80308568953-90967823164-21475724965-20604847064-89571150503-29979928429-10085366846-39828179808-29669314959-96532658547\"},{\"0\":\"97573031185-14444727291-41551890417-35722806936-46232057671-35289555628-23878118423-45843961314-65985344454-71884858957\"},{\"0\":\"80734294849-07956454545-82190680746-61161262901-20783884202-94726691836-53583482409-06654434179-75865644347-54863617582\"},{\"0\":\"38458387757-59108998151-18325425561-61697467497-13447946635-93949168697-29281847058-92371860768-38543627111-46707562753\"},{\"0\":\"78138788701-36918600041-22896553733-00559298659-68642689868-63208377694-63472480888-16817697336-27285994742-14539437993\"},{\"0\":\"62369190415-91586344249-14117969055-72890303452-48262382194-59016921265-85933292305-32131415317-90734458895-45626368739\"},{\"0\":\"83073006674-83147278988-29317048348-28598721444-38832886556-69991917821-31660337871-71924710709-74195468785-63356130012\"},{\"0\":\"67147139750-61522316643-75837900422-88505463884-50872085026-76175999461-31691170138-75004173234-21467709954-48773813353\"},{\"0\":\"89704434326-97761157658-79785029342-21073961839-69148815994-07670667517-41027587740-93877899647-70498260999-51812120092\"},{\"0\":\"32869671491-96030892194-25404728842-14212185216-20188500597-78647822602-54679204753-95180422120-81389706840-75370482381\"},{\"0\":\"63724129457-25490025201-91413184125-74537127007-02394725345-13066585012-18456318363-92140373069-13330295939-93476438136\"},{\"0\":\"71115769733-58976345967-27901573547-58076318726-70439502497-15511461733-19089861768-02395568211-56879438029-51867843774\"},{\"0\":\"53183390402-22724188592-39537698280-76839283114-53300959119-66114384524-27195703053-65150335955-18397508801-76232308315\"},{\"0\":\"44545172672-99018266096-93971670961-53099933845-58985815637-26639965445-86332428205-73508715481-31364975236-86266449922\"},{\"0\":\"93951187208-47678141074-55942694594-33649854747-61783075294-52440811753-09302203807-79972894902-12418534783-74495043128\"},{\"0\":\"72346911271-74492251054-99129314169-48819434513-15998964915-69118237019-22496385206-50855969901-95733162710-26305777098\"},{\"0\":\"61342748081-82738493778-73469040267-56615669711-30880759976-00805728380-44233565366-91927525734-68254536463-05616312913\"},{\"0\":\"65268312999-24264336883-76564706460-13835710459-58767245875-80661807226-19740844188-81615149495-27909623333-80081600175\"},{\"0\":\"60140902442-55105833021-71212898042-26314567666-27647428325-49820504131-00993690765-82242134921-31273459054-53202404252\"},{\"0\":\"57679717676-68176584380-81253146311-06396086478-32548833881-74312766648-62497778514-75375491832-39461302491-84695506096\"},{\"0\":\"85948236851-50846212111-25407182485-88975262111-97657187130-91879315129-95582504107-54877893358-31052624384-37715489389\"},{\"0\":\"60247266392-58187853613-45269070134-52854888434-79832962399-40662289319-86434347930-43816673510-20234812183-59507566815\"},{\"0\":\"62346522290-83536687726-68304440941-79520625064-11431362807-92940140941-02613345216-04210158575-55757459985-57151375004\"},{\"0\":\"91195016496-61594293068-57446668773-40157046848-33860049926-85437527749-96010151276-59537609170-30393898671-19114164782\"},{\"0\":\"45350107831-88302159731-93021868370-93196048902-48211333272-06679353451-60731654778-00582164620-08505392535-87164060946\"},{\"0\":\"53287641230-91939106669-49005204060-66084203239-42862599330-62309886647-73941790629-33566551095-80218664380-11274863160\"},{\"0\":\"20677138553-54245628460-19474117290-37705178523-77101239017-96885205722-83032378168-15915296945-41682765168-53842728920\"},{\"0\":\"91535113846-55531302579-84160497776-26684498143-30811001979-67498454430-93300209321-55553982773-62202236773-93006531149\"},{\"0\":\"48906412424-91706682463-90894319536-00802277100-20074874498-63265420697-99518996639-24564772731-37627587678-72237228320\"},{\"0\":\"72059737403-38426669404-81741062433-01985608044-27639675726-02742915071-82624593238-94545873751-16663879133-53085188428\"},{\"0\":\"71308193384-67269649697-76629455798-93893073871-21021342281-95749610641-35097956731-46178712866-37906918495-55298758443\"},{\"0\":\"36632492958-07255872922-56263285225-69778076846-16098372901-11190842068-93826727400-70062280065-06797816577-62982320572\"},{\"0\":\"29756237325-72514063947-55952110025-64803433070-00772475448-79585436037-90788017531-46422763525-75481764677-78496917875\"},{\"0\":\"69894315133-35897586709-78592370385-86633914212-17519681514-46095948012-11842389804-35449636385-85212600932-73503956977\"},{\"0\":\"87453176758-88916606435-97226370070-87401746826-52565526528-35931316791-79909083207-10103549240-68661196463-96250834690\"},{\"0\":\"08919416466-91384974214-52236267468-98721785763-82419185732-37652221269-84556492655-60960603456-17993042496-53510754933\"},{\"0\":\"24644797515-83938915071-02009923542-25069656100-05809810368-32429844447-43050815020-77510652734-31626783197-48708195628\"},{\"0\":\"54906054701-22659478997-15609871782-38031490794-26827355100-42984564965-17078005568-64764386810-78233000452-63783013060\"}],\"COLUMNS\":[{\"name\":\"c\",\"tablename\":\"sbtest1\"}],\"aid\":\"9\",\"tid\":\"6\"}";
			 * return ret_str; }
			 */
			JSONObject obj = new JSONObject(req.body());
			/*// System.out.println(obj);
			v_appid = obj.getString("aid");
			if (v_appid == null) {
				v_appid = appId;
			} 
				 * else { //Stubbing return obj.toString(); }
				 
			String encType = null;

			log.debug("Path5 is Processing No.Of records " + obj.getJSONArray("RECORDS").length());
			for (int i = 0; i < obj.getJSONArray("COLUMNS").length(); i++) {
				JSONObject table = obj.getJSONArray("COLUMNS").getJSONObject(i);
				String tablename = apiCalls.getEncryptedTableName(table.getString("tablename"), v_appid);
				String columnname = apiCalls.getEncryptedColName(table.getString("name"), v_appid);
				table.put("tablename", tablename);
				table.put("name", columnname);
				encType = (apiCalls.getEncType(tablename, columnname, v_appid));
				if (columnname.equalsIgnoreCase("id")) {
					encType = null;
				}

				for (int j = 0; j < obj.getJSONArray("RECORDS").length(); j++) {
					JSONObject value = obj.getJSONArray("RECORDS").getJSONObject(j);
					String dv = null;
					if (encType != null) {

						// System.out.println(tablename + ' '+ columnname + ' '+
						// encType + ' '+ value.getString(i + ""));
						String s = (String) apiCalls.getDecryptedColValue(encType, value.getString(i + ""));
						s = s.replace("\u0000", "");
						value.put(i + "", s);
					} else {

						if (tablename.equalsIgnoreCase("table_names")) {
							try {
								// value.put(i + "",
								// apiCalls.getDecryptedColValue(columnname,
								// value.getString(i + ""), tablename,v_appid));
								value.put(i + "", apiCalls.getEncryptedTableName(value.getString(i + ""), v_appid));
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						} else if (tablename.equalsIgnoreCase("columns")) {
							try {
								// value.put(i + "",
								// apiCalls.getDecryptedColValue(columnname,
								// value.getString(i + ""), tablename,v_appid));
								value.put(i + "", apiCalls.getEncryptedColName(value.getString(i + ""), v_appid));

							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}

				}
			}
			// System.out.println(obj);
*/			log.debug("Path5 enpoint completed  =====" + ((System.nanoTime() - startTime) / 1000000) + " ms");
			return obj.toString();

		});
		post("/path7", (req, res) -> {
			log.debug("started calling /path7");
			final long startTime = System.nanoTime();

			JSONObject obj = new JSONObject(req.body());
			// System.out.println(obj);
			String v_appid = obj.getString("aid");
			if (v_appid == null) {
				v_appid = appId;
			}
			String encType = null;
			log.debug("Path7 is Processing No.Of records " + obj.getJSONArray("RECORDS").length());
			for (int i = 0; i < obj.getJSONArray("COLUMNS").length(); i++) {
				JSONObject table = obj.getJSONArray("COLUMNS").getJSONObject(i);
				// String tablename =
				// apiCalls.getEncryptedTableName(table.getString("tablename"),v_appid);
				// String columnname =
				// apiCalls.getEncryptedColName(table.getString("name"),v_appid);
				String tablename = table.getString("tablename");
				String columnname = table.getString("name");
				table.put("tablename", tablename);
				table.put("name", columnname);
				encType = (apiCalls.getEncType(tablename, columnname, v_appid));

				for (int j = 0; j < obj.getJSONArray("RECORDS").length(); j++) {
					JSONObject value = obj.getJSONArray("RECORDS").getJSONObject(j);
					String dv = null;
					if (encType != null) {
						value.put(i + "", apiCalls.getEncryptedColValue(encType, value.getString(i + "")));

					}

				}
			}
			// System.out.println(obj);
			log.debug("Path7 enpoint completed  =====" + ((System.nanoTime() - startTime) / 1000000) + " ms");
			return obj.toString();

		});
		
		//ExfTest
		post("/path9", (req, res) -> {
			log.debug("started calling /path9");
			final long startTime = System.nanoTime();
			//System.out.println("req.body().toString()"+req.body().toString());
			String str  = req.body().toString();
			//byte[] resT = req.body().toString().getBytes(StandardCharsets.UTF_8);
		//	System.out.println("str::"+Base64.getDecoder().decode(str).length);
			try{
			AddSbtest sbtestClass = new AddSbtest();			
			SbTestMsgs sbtestParse = SbTestMsgs.parseFrom(Base64.getDecoder().decode(str));  // this will create sbtestParse java Object from byteArray
			//sbtestClass.ReadSbtest(sbtestParse);
			}catch(Exception e){
				e.printStackTrace();
				throw e;
				}
			//sbtestClass.ReadSbtest(sbtestParse); //This will create jsonObject from the sbtestParse java Object.
			//System.out.println("str.getBytes()::"+str.getBytes());
			//System.out.println("req.body().toString()	::"+req.body().toString());
			log.debug("Path9 enpoint completed  =====" + ((System.nanoTime() - startTime) / 1000000) + " ms");
		
			return str.getBytes();
		});
		
		
		get("/db", (req, res) -> {
			// String v_sql = req.queryParams("arg1");
			String host = req.queryParams("arg1");
			// return "ccp_lgh_db_0304";
			// return "date_test";
			// return "ccp_lgh_db_2703";
			String v_str = c.getDatabases(host);
			if (v_str != null) {
				return v_str;
			} else {
				return "";
			}
			// return "ccp_dates";
			// return "ccp_lgh_db_2703";
			// return "target_2404";
			// return c.getEncSchemas();
		});

		get("/reload", (req, res) -> {
			int reload = 1;
			api = new apiEndPoints(reload);
			return "Reloaded";
		});

	}


}
